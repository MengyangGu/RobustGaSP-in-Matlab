# RobustGaSP-in-Matlab
 This package is a RobustGaSP Package available in Matlab. The R version of the RobustGaSP Package is available at CRAN: https://cran.r-project.org/web/packages/RobustGaSP/index.html

The examples.m contain some examples. You need to compile the C++ files by compile_cpp() in Matlab and you only need to do it once. 

Two main functions are ppgasp() and prediction_predict_ppgasp(). Use help ppgasp() and help prediction_predict_ppgasp() to see how to use these functions. 
